CONTROLS FOR THE GAME:

ESC - open menu

First level:
W,S - change lanes
SPACE - jump

Second & Third levels:
W,A,S,D - movement
SPACE - slide
RCTRL, LEFT MOUSE CLICK - shoot

Google Forms (please complete it so I can write an analysis of my game :D)
https://forms.gle/UsgeDhJha9hALyV76